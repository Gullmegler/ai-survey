import React from 'react';
export default function App() { return <h1>AI Survey App</h1>; }