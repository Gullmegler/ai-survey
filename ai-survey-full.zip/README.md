# AI Survey

A standalone frontend for AI Survey, integrated with crm.airemovals.co.uk for light CRM functionality.